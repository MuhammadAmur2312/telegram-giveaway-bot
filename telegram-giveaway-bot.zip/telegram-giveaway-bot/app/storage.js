const fs = require("fs");

const dataFile = "storage.json";

// 📌 Fayl mavjudligini tekshirish va yaratish
if (!fs.existsSync(dataFile)) {
  fs.writeFileSync(dataFile, JSON.stringify({ users: [], contest: [] }));
}

// 📌 JSON fayldan ma'lumotlarni yuklash
const loadData = () => {
  const rawData = fs.readFileSync(dataFile);
  return JSON.parse(rawData);
};

// 📌 JSON faylga ma'lumotlarni saqlash
const saveData = (data) => {
  fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
};

// 📌 Foydalanuvchini ID ro‘yxatiga qo‘shish
const add = (userId) => {
  const data = loadData();
  if (!data.users.includes(userId)) {
    data.users.push(userId);
    saveData(data);
  }
};

// 📌 ID ro‘yxatda borligini tekshirish
const exists = (userId) => {
  const data = loadData();
  return data.users.includes(userId);
};

// 📌 Tanlovga ishtirokchini qo‘shish
const addToContest = (userId) => {
  const data = loadData();
  if (!data.contest.includes(userId)) {
    data.contest.push(userId);
    saveData(data);
  }
};

// 📌 Tasodifiy g‘olibni tanlash
const getRandomWinner = () => {
  const data = loadData();
  if (data.contest.length === 0) return null;
  
  const winnerIndex = Math.floor(Math.random() * data.contest.length);
  const winner = data.contest[winnerIndex];

  // 📌 G‘olibni tanlov ro‘yxatidan olib tashlash
  data.contest.splice(winnerIndex, 1);
  saveData(data);
  
  return winner;
};

module.exports = { add, exists, addToContest, getRandomWinner };