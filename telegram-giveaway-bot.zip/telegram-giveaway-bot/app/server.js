const { Telegraf } = require("telegraf");
const storage = require("./storage"); // ID larni saqlash uchun
const startHandler = require("./handlers/start");
const rulesHandler = require("./handlers/rules");
const joinHandler = require("./handlers/join");
const winnersHandler = require("./handlers/winners");

const bot = new Telegraf("BOT_TOKEN_HERE"); // Shu joyga bot tokenini yoz

// Komandalarni botga ulash
bot.start(startHandler);
bot.command("rules", rulesHandler);
bot.command("join", joinHandler);
bot.command("winners", winnersHandler);

bot.launch();
console.log("Bot ishlayapti...");

// Glitch uchun serverni ping qilish (5 daqiqada bir)
const express = require("express");
const app = express();
app.get("/", (req, res) => res.send("Bot ishlayapti!"));
app.listen(3000, () => console.log("Server 3000-portda ishga tushdi."));