const storage = require("../storage");

module.exports = (ctx) => {
  const userId = ctx.from.id;
  if (!storage.exists(userId)) {
    ctx.reply("Siz avval ID olishingiz kerak. /start bosing.");
  } else {
    storage.addToContest(userId);
    ctx.reply("Siz tanlovga muvaffaqiyatli qo‘shildingiz! 🎉");
  }
};