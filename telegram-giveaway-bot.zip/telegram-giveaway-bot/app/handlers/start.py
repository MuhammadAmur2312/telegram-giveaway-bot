const storage = require("../storage");

module.exports = (bot) => {
  bot.command("start", (ctx) => {
    const userId = ctx.from.id;

    if (!storage.exists(userId)) {
      storage.add(userId);
      ctx.reply(`🎉 Sizga ID berildi: ${userId}\n\nTanlovga qo‘shilish uchun /join ni bosing!`);
    } else {
      ctx.reply(`✅ Siz allaqachon ID olgansiz!\n\nTanlovga qo‘shilish uchun /join ni bosing.`);
    }
  });
};