const storage = require("../storage");

module.exports = (ctx) => {
  const winner = storage.getRandomWinner();
  if (winner) {
    ctx.reply(`🎉 G‘olib: ${winner} 🎉\nTabriklaymiz!`);
  } else {
    ctx.reply("Hali tanlovda ishtirokchilar yo‘q.");
  }
};