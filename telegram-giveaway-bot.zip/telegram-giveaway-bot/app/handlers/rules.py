module.exports = (ctx) => {
  ctx.reply("📜 Tanlov qoidalari:\n1. Tanlovda faqat ro‘yxatdan o‘tgan foydalanuvchilar ishtirok etishi mumkin.\n2. G‘olib tasodifiy tanlanadi.\n3. Shartlarga rioya qilmaganlar diskvalifikatsiya qilinadi.");
};